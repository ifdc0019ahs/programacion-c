// PRIMEROS PASOS EN PROGRAMACIÓN EN C: Bloque 2
#include <stdio.h>
int main(){
    printf("Bienvenidos al curso de C\n");
    printf("Estamos aprendiendo variables\n");
    printf("Y compilando programas\n");
    return 0;
}